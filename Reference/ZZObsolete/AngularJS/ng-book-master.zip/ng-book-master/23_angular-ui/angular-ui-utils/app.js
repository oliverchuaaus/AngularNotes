angular.module('myApp', ['ui.event'])

.controller('DemoController', ['$scope', function($scope) {
}]);
/** Automatically generated file. DO NOT MODIFY */
package io.fullstack.gapapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}